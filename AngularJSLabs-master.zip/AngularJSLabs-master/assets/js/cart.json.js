var theCart = [
    {
      "product":  {
        "productID" : 12,
        "productName" : "Another fake product",
        "supplierID" : 8,
        "categoryID" : 3,
        "quantityPerUnit" : "Box of 12",
        "unitPrice" : 11.23,
        "unitsInStock" : 40,
        "unitsOnOrder" : 0,
        "reorderLevel" : 0,
        "discontinued" : 0,
        "featured" : true
      },
      "quantity": 4
    },
    {
      "product":  {
        "productID" : 25,
        "productName" : "A fourth fake product",
        "supplierID" : 8,
        "categoryID" : 4,
        "quantityPerUnit" : "Box of 12",
        "unitPrice" : 81.34,
        "unitsInStock" : 40,
        "unitsOnOrder" : 0,
        "reorderLevel" : 0,
        "discontinued" : 0,
        "featured" : true
      },
      "quantity": 2
    },
    {
      "product":  {
        "productID" : 55,
        "productName" : "This hardcoded product",
        "supplierID" : 8,
        "categoryID" : 4,
        "quantityPerUnit" : "A plethora",
        "unitPrice" : 44.25,
        "unitsInStock" : 40,
        "unitsOnOrder" : 0,
        "reorderLevel" : 0,
        "discontinued" : 0,
        "featured" : true
      },
      "quantity": 2
    }
  ];
