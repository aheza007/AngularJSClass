(function () {
  angular.module("mainModule", ['sharedModule']);
})();
