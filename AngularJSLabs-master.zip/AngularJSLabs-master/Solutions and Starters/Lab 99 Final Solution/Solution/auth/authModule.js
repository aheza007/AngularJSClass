(function () {
  'use strict';
  angular.module("authModule",['sharedModule']);
})();