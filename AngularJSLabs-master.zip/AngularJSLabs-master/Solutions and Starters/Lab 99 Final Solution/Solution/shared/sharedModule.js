/**
 * Created by rap on 9/18/15.
 */
(function () {
  angular.module('sharedModule', []);
})();